
Admin Setup (Decap/Netlify CMS)
-------------------------------
1) Push this folder to a GitHub repo.
2) Netlify > New site from Git > connect repo > Publish dir: .
3) Netlify > Identity > Enable Identity (Invite-only).
4) Netlify > Identity > Services > Enable Git Gateway.
5) Netlify > Identity > External providers > Enable Google.
6) Visit https://YOURDOMAIN/admin/ and login with Google.

Local test (optional):
- Uncomment `local_backend: true` in /admin/config.yml
- Run: `npx decap-server` and `python -m http.server 8080`
- Open http://localhost:8080/admin/
