See README for local run and Netlify deploy steps.
